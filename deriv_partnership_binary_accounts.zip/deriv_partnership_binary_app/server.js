const express = require('express');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const SESSION_SECRET = process.env.SESSION_SECRET;
if (!SESSION_SECRET || SESSION_SECRET.length < 32) {
  console.error('Set SESSION_SECRET to a long random value (at least 32 characters).');
  process.exit(1);
}

const db = new Database(process.env.DB_FILE || path.join(__dirname, 'data.sqlite'));
db.pragma('journal_mode = WAL');
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    balance_kes REAL NOT NULL DEFAULT 1000000,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    pair TEXT NOT NULL,
    side TEXT NOT NULL CHECK(side IN ('BUY','SELL')),
    size_kes REAL NOT NULL,
    entry_price REAL NOT NULL,
    exit_price REAL,
    pnl_kes REAL,
    status TEXT NOT NULL DEFAULT 'OPEN' CHECK(status IN ('OPEN','CLOSED')),
    opened_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    closed_at TEXT,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );
`);

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '20kb' }));
app.use(session({
  store: new SQLiteStore({ db: 'sessions.sqlite', dir: __dirname }),
  name: 'dpb.sid',
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 1000 * 60 * 60 * 24 * 7
  }
}));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 12, standardHeaders: true, legacyHeaders: false });
app.use('/api/register', authLimiter);
app.use('/api/login', authLimiter);
app.use(express.static(path.join(__dirname, 'public')));

function safeUser(id) {
  return db.prepare('SELECT id, name, email, balance_kes AS balanceKes FROM users WHERE id = ?').get(id);
}
function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: 'Please log in to continue.' });
  next();
}
function validEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 254;
}
function validPair(pair) {
  return ['EUR/USD','GBP/USD','USD/JPY','AUD/USD','USD/CAD'].includes(pair);
}
function priceValid(price) {
  return typeof price === 'number' && Number.isFinite(price) && price > 0;
}

app.get('/api/me', (req, res) => {
  if (!req.session.userId) return res.json({ user: null });
  const user = safeUser(req.session.userId);
  if (!user) { req.session.destroy(() => {}); return res.json({ user: null }); }
  res.json({ user });
});

app.post('/api/register', async (req, res) => {
  const name = String(req.body.name || '').trim();
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (name.length < 2 || name.length > 70) return res.status(400).json({ error: 'Enter a name between 2 and 70 characters.' });
  if (!validEmail(email)) return res.status(400).json({ error: 'Enter a valid email address.' });
  if (password.length < 10 || password.length > 72) return res.status(400).json({ error: 'Use a password between 10 and 72 characters.' });
  if (!/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) return res.status(400).json({ error: 'Your password must include at least one letter and one number.' });
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare('INSERT INTO users (name, email, password_hash, balance_kes) VALUES (?, ?, ?, 1000000)').run(name, email, hash);
    req.session.userId = result.lastInsertRowid;
    res.status(201).json({ user: safeUser(result.lastInsertRowid) });
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) return res.status(409).json({ error: 'An account with that email already exists.' });
    console.error(e); res.status(500).json({ error: 'Could not create the account.' });
  }
});

app.post('/api/login', async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const row = db.prepare('SELECT id, password_hash FROM users WHERE email = ?').get(email);
  if (!row || !(await bcrypt.compare(password, row.password_hash))) return res.status(401).json({ error: 'Email or password is incorrect.' });
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: 'Could not start your session.' });
    req.session.userId = row.id;
    res.json({ user: safeUser(row.id) });
  });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) return res.status(500).json({ error: 'Could not log out.' });
    res.clearCookie('dpb.sid', { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production' });
    res.json({ ok: true });
  });
});

app.get('/api/trades', requireAuth, (req, res) => {
  const trades = db.prepare(`SELECT id, pair, side, size_kes AS sizeKes, entry_price AS entryPrice,
    exit_price AS exitPrice, pnl_kes AS pnlKes, status, opened_at AS openedAt, closed_at AS closedAt
    FROM trades WHERE user_id = ? ORDER BY id DESC LIMIT 100`).all(req.session.userId);
  res.json({ trades });
});

app.post('/api/trades', requireAuth, (req, res) => {
  const pair = String(req.body.pair || '');
  const side = String(req.body.side || '');
  const sizeKes = Number(req.body.sizeKes);
  const entryPrice = Number(req.body.entryPrice);
  if (!validPair(pair)) return res.status(400).json({ error: 'Choose a supported Forex pair.' });
  if (!['BUY','SELL'].includes(side)) return res.status(400).json({ error: 'Choose BUY or SELL.' });
  if (!Number.isFinite(sizeKes) || sizeKes < 100 || sizeKes > 1000000) return res.status(400).json({ error: 'Trade size must be between KSh 100 and KSh 1,000,000.' });
  if (!priceValid(entryPrice)) return res.status(400).json({ error: 'Invalid simulated price.' });
  const user = safeUser(req.session.userId);
  if (sizeKes > user.balanceKes) return res.status(400).json({ error: 'Not enough virtual KES balance.' });
  const transact = db.transaction(() => {
    db.prepare('UPDATE users SET balance_kes = balance_kes - ? WHERE id = ?').run(sizeKes, req.session.userId);
    const info = db.prepare('INSERT INTO trades (user_id, pair, side, size_kes, entry_price) VALUES (?, ?, ?, ?, ?)').run(req.session.userId, pair, side, sizeKes, entryPrice);
    return info.lastInsertRowid;
  });
  const id = transact();
  res.status(201).json({ user: safeUser(req.session.userId), trade: db.prepare('SELECT id, pair, side, size_kes AS sizeKes, entry_price AS entryPrice, status, opened_at AS openedAt FROM trades WHERE id = ?').get(id) });
});

app.post('/api/trades/:id/close', requireAuth, (req, res) => {
  const exitPrice = Number(req.body.exitPrice);
  if (!priceValid(exitPrice)) return res.status(400).json({ error: 'Invalid simulated price.' });
  const trade = db.prepare("SELECT * FROM trades WHERE id = ? AND user_id = ? AND status = 'OPEN'").get(Number(req.params.id), req.session.userId);
  if (!trade) return res.status(404).json({ error: 'Open trade not found.' });
  // Demo P/L model only: small movement-based return, capped to avoid extreme results from bad inputs.
  const relativeMove = (exitPrice - trade.entry_price) / trade.entry_price * (trade.side === 'BUY' ? 1 : -1);
  const pnlKes = Math.max(-trade.size_kes, Math.min(trade.size_kes * 0.25, trade.size_kes * relativeMove * 20));
  const transact = db.transaction(() => {
    db.prepare("UPDATE trades SET status='CLOSED', exit_price=?, pnl_kes=?, closed_at=CURRENT_TIMESTAMP WHERE id=? AND status='OPEN'").run(exitPrice, pnlKes, trade.id);
    db.prepare('UPDATE users SET balance_kes = balance_kes + ? + ? WHERE id = ?').run(trade.size_kes, pnlKes, req.session.userId);
  });
  transact();
  res.json({ user: safeUser(req.session.userId), trade: db.prepare('SELECT id, pair, side, size_kes AS sizeKes, entry_price AS entryPrice, exit_price AS exitPrice, pnl_kes AS pnlKes, status, opened_at AS openedAt, closed_at AS closedAt FROM trades WHERE id = ?').get(trade.id) });
});

app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.listen(PORT, () => console.log(`Deriv partnership Binary demo running on port ${PORT}`));
